function ValidateForm(){
      
    var name = document.getElementById("name").value.trim();
 
    if (!name){
        alert("Name is empty");
        return false;
    }
    var email = document.getElementById("email").value.trim();
    if (!email){
        alert("Email is empty");
        return false;
    }
    var subject = document.getElementById("subject").value.trim();
    if (!subject){
        alert("Subject is empty");
         return false;
     }
     var Message = document.getElementById("message").value.trim();
    if (!Message){
        alert("Message  is empty");
         return false;
     }
    alert(`Thankyou for your feedback ${name}`);
}

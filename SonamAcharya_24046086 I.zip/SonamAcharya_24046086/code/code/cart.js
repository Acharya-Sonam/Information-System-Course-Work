//declearing all the variable/constants
let cartitems = 0;
const itemList = document.getElementById("cart-items");
const totalPrice = document.getElementById("totalprice");
const emptycartmsg = document.getElementById("empty-cartmsg");
let cart = [];

//To increase Indicator in Addtocart Icon
function updateCartCount() {
  document.getElementById("total-items").textContent = cartitems;

  //Logic for Msg to be displayed when cart is empty
  if (cartitems === 0) {
    emptycartmsg.style.display = "flex";
  } else {
    emptycartmsg.style.display = "none";
  }
}
//Toast msg
function toast() {
  var toastmsg = document.querySelector(".toast");
  toastmsg.style.opacity = 1;
  setTimeout(function () {
    toastmsg.style.opacity = 0;
  }, 1500);
}
//to update cart UI when a item is added to cart
function updateCartUi() {
  const cartItemList = document.querySelector(".itemList");
  console.log(cartItemList);
  cartItemList.innerHTML = "";

  let totalItemPrice = 0;
  //function to create a devision for items and elements inside it
  cart.forEach((item) => {
    const itemDiv = document.createElement("div");
    itemDiv.classList.add("items");

    const itemImage = document.createElement("img");
    itemImage.src = item.image;
    itemImage.alt = item.name;
    itemImage.classList.add("cartitem-img");

    const detailsDiv = document.createElement("div");
    detailsDiv.classList.add("cartitem-details");

    const itemName = document.createElement("h3");
    itemName.textContent = item.name;
    itemName.classList.add("cartitem-name");

    const itemPrice = document.createElement("p");
    itemPrice.textContent = `Rs: ${item.price}`;
    itemPrice.classList.add("cartitem-price");

    detailsDiv.append(itemName, itemPrice);
    //function for remove button 
    const buttonDiv = document.createElement("div");
    buttonDiv.classList.add("buttonDiv");
    const removeButton = document.createElement("button");
    removeButton.innerHTML = '<i class="fas fa-trash"></i>';
    removeButton.classList.add("removeBtn");

    const itemQuantity = document.createElement("p");
    itemQuantity.textContent = `Qty:${item.quantity}`;
    itemQuantity.classList.add("cartitem-quantity");

    buttonDiv.append(removeButton, itemQuantity);

    removeButton.addEventListener("click", function () {
      event.stopPropagation();
      removeItemAndDiv(item.id, itemDiv);
    });
    // adding everything to the Item divison
    itemDiv.append(itemImage, detailsDiv, buttonDiv);

    // adding item division to the cartcard
    cartItemList.appendChild(itemDiv);

    totalItemPrice += item.price * item.quantity;
  });
  totalPrice.textContent = `Rs:${totalItemPrice.toFixed(2)}`;
}
//To remove item from cart
function removeItemAndDiv(id, itemDiv) {
  const itemIndex = cart.findIndex((item) => item.id === id);
  if (itemIndex > -1) {
    cartitems -= cart[itemIndex].quantity;
    cart.splice(itemIndex, 1);
    updateCartCount();
    updateCartUi();
  }
  document.getElementById("cartcard").style.display = "block";
}
// this function recive massage from productpage and home page
window.addEventListener("message", function (event) {
  if (event.data.type === "add-to-cart") {
    const { id, name, price, image } = event.data;
    const existingItem = cart.find((item) => item.id === id);
    if (existingItem) {
      existingItem.quantity++;
    } else {
      cart.push({
        id: id,
        name: name,
        price: price,
        image: image,
        quantity: 1,
      });
    }

    cartitems++;
    toast();
    updateCartCount();
    updateCartUi();
  }
});
